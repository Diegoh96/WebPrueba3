const express = require("express");

const router =
express.Router();

const controller =
require("../controllers/productController");

const auth =
require("../middlewares/auth");

router.get(
    "/",
    controller.getProducts
);

router.get(
    "/:id",
    controller.getProductById
);

router.post(
    "/",
    auth,
    controller.createProduct
);

module.exports = router;