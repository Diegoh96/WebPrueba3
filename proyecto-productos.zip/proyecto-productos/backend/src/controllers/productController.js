const service =
require("../services/productService");

const getProducts = (req,res)=>{

    service.getAll((error,data)=>{

        if(error){

            return res.status(500).json({
                mensaje:"Error servidor"
            });

        }

        res.status(200).json(data);

    });

};

const getProductById = (req,res)=>{

    service.getById(
        req.params.id,
        (error,data)=>{

            if(error){

                return res.status(500).json({
                    mensaje:"Error servidor"
                });

            }

            if(data.length===0){

                return res.status(404).json({
                    mensaje:"Producto no encontrado"
                });

            }

            res.status(200).json(data[0]);

        }
    );

};

const createProduct = (req,res)=>{

    const {
        nombre,
        precio,
        stock
    } = req.body;

    if(!nombre || !precio || !stock){

        return res.status(400).json({
            mensaje:"Todos los campos son obligatorios"
        });

    }

    service.create(
        req.body,
        (error)=>{

            if(error){

                return res.status(500).json({
                    mensaje:"Error al guardar"
                });

            }

            res.status(201).json({
                mensaje:"Producto creado"
            });

        }
    );

};

module.exports = {
    getProducts,
    getProductById,
    createProduct
};