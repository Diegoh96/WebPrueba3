const API_KEY = "123456";

const auth = (req,res,next)=>{

    const apiKey = req.headers["x-api-key"];

    if(!apiKey){

        return res.status(401).json({
            mensaje:"API KEY requerida"
        });

    }

    if(apiKey !== API_KEY){

        return res.status(403).json({
            mensaje:"API KEY incorrecta"
        });

    }

    next();
};

module.exports = auth;