const mysql = require("mysql2");

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "veterinaria"
});

connection.connect((error) => {

    if(error){
        console.log("Error BD:", error);
    }else{
        console.log("MySQL conectado");
    }

});

module.exports = connection;