const productData =
require("../data/productData");

module.exports = productData;