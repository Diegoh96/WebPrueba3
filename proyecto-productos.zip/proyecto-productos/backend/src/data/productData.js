const db = require("../config/db");

const getAll = (callback)=>{

    db.query(
        "SELECT * FROM productos",
        callback
    );

};

const getById = (id,callback)=>{

    db.query(
        "SELECT * FROM productos WHERE id=?",
        [id],
        callback
    );

};

const create = (producto,callback)=>{

    db.query(
        "INSERT INTO productos(nombre,precio,stock) VALUES(?,?,?)",
        [
            producto.nombre,
            producto.precio,
            producto.stock
        ],
        callback
    );

};

module.exports = {
    getAll,
    getById,
    create
};