const express = require("express");
const cors = require("cors");

const logger =
require("./middlewares/logger");

const app = express();

app.use(cors());
app.use(express.json());
app.use(logger);

app.use(
    "/api/productos",
    require("./routes/productRoutes")
);

app.get("/",(req,res)=>{

    res.send(
        "API Veterinaria funcionando"
    );

});

app.listen(3000,()=>{

    console.log(
        "Servidor corriendo en puerto 3000"
    );

});