const formulario =
document.getElementById("formulario");

formulario.addEventListener(
"submit",
async(event)=>{

event.preventDefault();

const producto = {

nombre:
document.getElementById("nombre").value,

precio:
document.getElementById("precio").value,

stock:
document.getElementById("stock").value

};

try{

const respuesta =
await fetch(
"http://localhost:3000/api/productos",
{
method:"POST",

headers:{
"Content-Type":"application/json",
"x-api-key":"123456"
},

body:JSON.stringify(producto)
}
);

const data =
await respuesta.json();

document.getElementById(
"resultado"
).innerHTML =
data.mensaje;

listarProductos();

formulario.reset();

}catch(error){

document.getElementById(
"resultado"
).innerHTML =
"Error al registrar";

}

});

async function listarProductos(){

try{

const respuesta =
await fetch(
"http://localhost:3000/api/productos"
);

const productos =
await respuesta.json();

const tabla =
document.getElementById(
"tablaProductos"
);

tabla.innerHTML = "";

productos.forEach(producto=>{

tabla.innerHTML += `
<tr>
<td>${producto.id}</td>
<td>${producto.nombre}</td>
<td>$${producto.precio}</td>
<td>${producto.stock}</td>
</tr>
`;

});

}catch(error){

console.log(error);

}

}

listarProductos();